<section id="nieuwsbrief">
        <div class="container">
            <div id="subscribe">
                <div>
                     <?php print t('<label for="optin-email">Schrijf je in om up-to-date te blijven!</label>') ?>
                </div>
                <div class="nieuwsbriefwrapper">
                    <div class="col-sm-12">
                        <input type="text" name="optin-email" id="optin-email" placeholder="Uw email adres">
                        <div class="nieuwsbriefmargin"></div>
                        <input type="submit" value="Verzend">
                    </div>
                </div>
            </div>
        </div>
    </section>  