<footer class="text-center">
    <div class="footer-above">
        <div class="container">
            <div class="row">
                <div class="footer-col col-md-4 footercontact">
                    <?php print t('<h3>Contact</h3></br></br>') ?>
                    <?php print t('<p>ask@viago.be</p></br>') ?>
                    <?php print t('<p>+32 266 02 3273</p></br>') ?>

                </div>
                <div class="footer-col col-md-4 footervolg">
                    <?php print t('<h3>Volg ViaGo</h3></br></br>') ?>
                    <?php print t('<p><a href="https://www.facebook.com/ViaGoGidsen/">Facebook</a></p></br>') ?>
                    <?php print t('<p>#ViaGo</p> </br>') ?>
                </div>
                <div class="footer-col col-md-4 footerlogo">
                <p><img src="<?php print $img_url . '/negative_viago.png' ?>" />
                </div></p>
            </div>
        </div>
    </div>
</footer>