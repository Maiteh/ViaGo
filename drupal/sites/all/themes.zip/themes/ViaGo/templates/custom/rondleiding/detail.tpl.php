<div id="fotos">
    <div class="container">
        <div class="row">
            <div class="col-xs-6">
                <h1>Het beste van Brugge</h1>
                <img src="assets/img/starts.png" width="40%" id="rating" />
                <p>(244 beoordelingen)</p>
                <img src="assets/img/gent_1.jpg" width="100%" id="hoofdFoto" />
                <div class="row">
                     <div class="col-xs-6 col-sm-3"><img src="assets/img/bicyclePicture.jpg" width="100%" /></div>
                     <div class="col-xs-6 col-sm-3"><img src="assets/img/bruggeommeland.jpg" width="100%" /></div>
                     <div class="col-xs-6 col-sm-3"><img src="assets/img/curch.jpg" width="100%" /></div>
                     <div class="col-xs-6 col-sm-3"><img src="assets/img/bestofbrugge.jpg" width="100%" /></div>
                </div>
                <div id="like">
                     <img src="assets/img/hart.svg" width="10%">Voeg toe aan je favorieten
                </div>
            </div>
            <div class="col-xs-6" id="comment">
                <div class="col-xs-6 col-md-4"></div>
                <div class="col-xs-6 col-md-4"><p>Uw enthousiaste gids</p> <strong>Glenn Sterckx</strong></div>
                <div class="col-xs-6 col-md-4"><img src="assets/img/glenn_sterckx.jpg" width="60%" /></div>
                <div id="price">
                    <img src="assets/img/ticket.svg" width="60%" />
                </div>
                <div id="commentaar">
                    <img src="assets/img/starts.png" width="30%" id="rating" />
                    <h2>"Het was een ontzettend fijne </br> ervaring, de 4 uur vlogen voorbij"</h2>
                    <p>Marjolijn Dekkers, 23 april 2016</p>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="infoBlok">
    <div class="container">
        <div class="row">
            <div class="col-xs-6">
                <h2>Beknopt</h2>
                <p><img src="assets/img/locatie.svg" width="5%"/>Brugge</p>
                <p><img src="assets/img/money_zwart_viago.svg" width="5%"/>€60 p.p.</p>
            </div>
            <div class="col-xs-6">
            </div>
        </div>
    </div>
</div>
    </div>